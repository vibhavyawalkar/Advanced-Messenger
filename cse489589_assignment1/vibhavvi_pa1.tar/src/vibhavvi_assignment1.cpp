/**
 * @vibhavvi_assignment1
 * @author  Vibhav Virendra Yawalkar <vibhavvi@buffalo.edu>
 * @version 1.0
 *
 * @section LICENSE
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details at
 * http://www.gnu.org/copyleft/gpl.html
 *
 * @section DESCRIPTION
 *
 * This contains the main function. Add further description here....
 */
#include <iostream>
#include <stdio.h>
#include <string.h>
#include <cstring>
#include <sstream>
#include <vector>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <netdb.h>

#include "../include/global.h"
#include "../include/logger.h"

using namespace std;

int connect_to_host(string &server_ip, string &server_port);

/**
 * main function
 *
 * @param  argc Number of arguments
 * @param  argv The argument list
 * @return 0 EXIT_SUCCESS
 */
int main(int argc, char **argv)
{
	/*Init. Logger*/
	cse4589_init_log(argv[2]);

	/* Clear LOGFILE*/
    fclose(fopen(LOGFILE, "w"));

	/*Start Here*/
    // Server Code
    cout << "argc:" << argc;
    for(int i = 0; i < argc; i++)
	    cout << argv[i] << " ";
    string cmd_input = "";
    vector<string> tokens;
    if(argc == 3 && strcmp(argv[1], "s") == 0)
    {
        while(1) {
	    getline(cin, cmd_input);

	    stringstream line(cmd_input);

	    string str;
	    while(getline(line, str, ' ')) {
                tokens.push_back(str);
	    }


	    if(strcmp(tokens[0].c_str(), "AUTHOR") == 0)
	    {
	        cse4589_print_and_log("[%s:SUCCESS]\n", cmd_input.c_str());
                cse4589_print_and_log("I, %s, have read and understood the course academic integrity policy.\n", "vibhavvi");
	    } else if(strcmp(tokens[0].c_str(), "IP") == 0) {
                cse4589_print_and_log("[%s:SUCCESS]\n", cmd_input.c_str());
                cse4589_print_and_log("IP:%s\n", "ip_addr");
            } else if(strcmp(tokens[0].c_str(), "PORT") == 0) {
                cse4589_print_and_log("[%s:SUCCESS]\n", cmd_input.c_str());
                cse4589_print_and_log("PORT:%d\n", "7855");
            } else if(strcmp(tokens[0].c_str(), "LIST") == 0) {
                cse4589_print_and_log("[%s:SUCCESS]\n", cmd_input.c_str());
                cse4589_print_and_log("host list\n");
            } /* Server only commands */
	      else if(strcmp(tokens[0].c_str(), "STATISTICS") == 0) {
		cse4589_print_and_log("[%s:SUCCESS]\n", cmd_input.c_str());
		cse4589_print_and_log("Statistics\n");
	    } else if(strcmp(tokens[0].c_str(), "BLOCKED") == 0) {
		cse4589_print_and_log("[%s:SUCCESS]\n", cmd_input.c_str());
	    } else {/*NOT USED */}
	}
    } else if(argc == 2 && strcmp(argv[1], "c") == 0) { // Client code
	getline(cin, cmd_input);
	stringstream line(cmd_input);
	string str;
	while(getline(line, str, ' ')) {
            tokens.push_back(str);
	}

	if(strcmp(tokens[0].c_str(), "AUTHOR") == 0) {
	    cse4589_print_and_log("[%s:SUCCESS]\n", cmd_input.c_str());
            cse4589_print_and_log("I, %s, have read and understood the course academic integrity policy.\n", "vibhavvi");
        } else if(strcmp(tokens[0].c_str(), "IP") == 0) {
	    cse4589_print_and_log("[%s:SUCCESS]\n", cmd_input.c_str());
	    cse4589_print_and_log("IP:%s\n", "ip_addr");
	} else if(strcmp(tokens[0].c_str(), "PORT") == 0) {
	    cse4589_print_and_log("[%s:SUCCESS]\n", cmd_input.c_str());
	    cse4589_print_and_log("PORT:%d\n", "7855");
	} else if(strcmp(tokens[0].c_str(), "LIST") == 0) {
	    cse4589_print_and_log("[%s:SUCCESS]\n", cmd_input.c_str());
	    cse4589_print_and_log("host list\n");
	} /* Client only commands start here */
	  else if(strcmp(tokens[0].c_str(), "LOGIN") == 0) {
	    cse4589_print_and_log("[%s:SUCCESS]\n", cmd_input.c_str());
	    cout << "Connect to Server " << tokens[1] << ":" << tokens[2];
            int fd = connect_to_host(tokens[1], tokens[2]);
	} else if(strcmp(tokens[0].c_str(), "REFRESH") == 0) {
	    cse4589_print_and_log("[%s:SUCCESS]\n", cmd_input.c_str());

	} else if(strcmp(tokens[0].c_str(), "SEND") == 0) {
	    cse4589_print_and_log("[%s:SUCCESS]\n", cmd_input.c_str());
	    cout << "Send message to client " << tokens[1] << ":" << tokens[2];
	} else if(strcmp(tokens[0].c_str(), "BROADCAST") == 0) {
	    cse4589_print_and_log("[%s:SUCCESS]\n", cmd_input.c_str());
	    cout << "Message " << tokens[1];
	} else if(strcmp(tokens[0].c_str(), "BLOCK") == 0) {
            cse4589_print_and_log("[%s:SUCCESS]\n", cmd_input.c_str());
	    cout << "Client IP " << tokens[1];
	} else if(strcmp(tokens[0].c_str(), "UNBLOCK") == 0) {
	    cse4589_print_and_log("[%s:SUCCESS]\n", cmd_input.c_str());
	    cout << "Unblock IP " << tokens[1];
	} else if(strcmp(tokens[0].c_str(), "LOGOUT") == 0) {
	    cse4589_print_and_log("[%s:SUCCESS]\n", cmd_input.c_str());
	} else if(strcmp(tokens[0].c_str(), "EXIT") == 0) {
            cse4589_print_and_log("[%s:SUCCESS]\n", cmd_input.c_str());
	}
    } else {
	cse4589_print_and_log("[%s:ERROR]\n", cmd_input.c_str());
    }
    cse4589_print_and_log("[%s:END]\n", cmd_input.c_str());
    return 0;
}

int connect_to_host(string &server_ip, string &server_port)
{
    struct addrinfo hints, *res;

    /* Set up hints structure */
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;

    /* Fill up address structures */
    if(getaddrinfo(server_ip.c_str(), server_port.c_str(), &hints, &res) != 0)
        perror("getaddrinfo failed");

    /* Create Socket */
    int fdsocket = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    if(fdsocket < 0)
        perror("Failed to create socket");

    /* Connect or login to the server */
    if(connect(fdsocket, res->ai_addr, res->ai_addrlen) < 0)
        perror("Connect failed");

    freeaddrinfo(res);
    return fdsocket;
}
